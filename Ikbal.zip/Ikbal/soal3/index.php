<?php
    $star=5;
    for ($i=$star; $i > 0 ; $i--) {
        for ($j=1; $j<=$i; $j++){
            echo "&nbsp";
        }
        for ($k=$star * 2; $k >= $i; $k--) {
            echo " * ";
        }
        echo "<br>";
    }

?>