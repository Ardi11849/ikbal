<?php

$angka = [5,9,5,6,5,6,0,1,5,9,4,6,6,0,5,6];

// $angka = array('5','9','5','6','5','6','0','1','5','9','4','6','6','0','5','6');
// // if(in_array('0'))
// sort($angka);
// echo $angka;

$hasil1 = array();
$hasil2 = array();
foreach($angka as $a){
    if($a != 0){
        array_push($hasil1, $a);
    }
    if($a == 0){
    break;
    }
    echo $a.' ';
}
function sorting($angka)
{
    $nilai = count($angka);
    for ($i=1; $i < $nilai; $i++) {
        for ($j=$i; $j >0 ; $j--) { 
            if($angka[$j] < $angka[$j - 1]){
                $dum = $angka[$j];
                $angka[$j] = $angka[$j-1];
                $angka[$j-1] = $dum;
            }
        }
    }
    return $angka;
}

print_r(sorting($hasil1));