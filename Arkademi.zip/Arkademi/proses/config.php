<?php
    $db = New Mysqli('localhost','root','','test');