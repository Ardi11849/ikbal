<?php

    include("config.php");

    $id = $_POST['Id_cassier'];
    $nama = $_POST['Name'];
    $price = $_POST['Price'];
    $category = $_POST['Id_category'];


    $query = $db->query("UPDATE Product SET Id='$id', Name='$nama', Id_category='$category', Price='$price' WHERE id='$id'");

    if ($query) {
        echo "<script>alert('Berhasil Mengubah Data Ke Database');document.location.href='../index.php'</script>";
    }else {
        echo "<script>alert('Gagal Mengubah Data Ke Database');document.location.href='../index.php'</script>";
    }