<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Arkademy TEST</title>

    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="assets/font-awesome/4.5.0/css/font-awesome.min.css" />
</head>

<body>
    <header>
        <div class="container">
            <img src="assets/img/logo.svg" >
            <h2>ARKADEMY TEST</h2>
            <div class="clearfix"></div>
        </div>
    </header>

    <div class="container">

        <button id="button-add">ADD</button>

        <div class="bg-form">
            <form action="proses/prosesTambah.php" method="post" id="form">
                <div class="form-header">
                    <div class="container">
                        <h4>ADD DATA</h4>
                        <button type="button" id="close">X</button>
                    </div>
                </div>
                <div class="form-body">
                    <div class="container">
                      <input type="text" name="Id_cassier" id="Id_cassier" Placeholder=Cassier required>
                      <br><br>
                        <input type="text" name="Name" id="Name" placeholder="Name..." autofocus="on" required>
                        <br><br>
   <input type="text" name="Id_category" id="Id_category" placeholder="Category" autofocus="on" required>
                       <br><br>
                                                                                         <input type="text" name="Price" Id="Price" placeholder="Price" autofocus="on" required>

 <br><br>

                        <button type="submit" id="add">ADD</button>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </form>
        </div>



        <table>
            <thead>
                <tr>
                    <th>Cassier</th>
                    <th>Product</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Action</th>

                </tr>
            </thead>
            <tbody>

                <?php
                include("proses/config.php");
                $query = $db->query("SELECT * FROM Product");
                while ($a = $query->fetch_array()) {
                    echo "
                        <tr>
                            <td>$a[Id_cassier]</td>
                            <td>$a[Name]</td>
                            <td>$a[Id_category]</td>
                            <td>$a[Price]</td>



                              <td>  <button style='background: transparent;border: none' Id_cassier='$a[Id_cassier]' Name='$a[Name]' Id_category='$a[Id_category]' Price='$a[Price]' class='doDelete'><i class='fa fa-trash' style='color: rgb(230, 109, 109);font-size: 20px'></i></button>

                                <a href='update.php?Id_cassier=' $[Id_cassiee]id='button-update' Id_category='$a[Id_cassier]' Name='$a[Name]' Id_category='$a[Id_category]' Price='$a[Price]'><i class='fa fa-edit' style='color: rgb(80, 212, 173);font-size: 20px'></i></a>
                            </td>
                        </tr>
                    ";
                }
                ?>
            </tbody>
        </table>

    </div>

    <!-- Javascript -->
    <script src="assets/js/jquery-3.3.1.js"></script>
    <script src="assets/js/style.js"></script>
</body>

</html>