<?php

    include("config.php");

    $casir = $_POST['Id_cassier'];
    $nama = $_POST['Name'];
    $Category = $_POST['Id_category'];
    $price = $_POST['Price'];

    $query = $db->query("INSERT INTO Product(Id_cassier,Name,Id_category,Price) VALUES('$casir' $nama','$Category',''$price')");

    if ($query) {
        echo "<script>alert('Berhasil Menambahkan Data Ke Database');document.location.href='../index.php'</script>";
    }else {
        echo "<script>alert('Gagal Menambahkan Data Ke Database');document.location.href='../index.php'</script>";
    }