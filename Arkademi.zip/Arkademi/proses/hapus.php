<?php

    include("config.php");
    $query = $db->query("DELETE FROM Product WHERE Id='$_GET[Id_cassier]'  Name='$_GET[Name]' Id_Category='$_GET[Id_category]'");
    header('location: ../index.php');