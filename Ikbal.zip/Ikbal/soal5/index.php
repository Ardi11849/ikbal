<?php

$angka1 = rand(1,99);
$angka2 = rand(1,99);
$angka3 = rand(1,99);
$angka4 = rand(1,99);
$angka5 = rand(1,99);
$angka6 = rand(1,99);
$angka7 = rand(1,99);
$angka8 = rand(1,99);
$angka9 = rand(1,99);
$jumlah = ($angka1+$angka5+$angka9)+($angka7+$angka5+$angka3);
echo "| ".$angka1."  ".$angka2."  ".$angka3."|<br>";
echo "| ".$angka4."  ".$angka5."  ".$angka6."|<br>";
echo "| ".$angka7."  ".$angka8."  ".$angka9."|<br>";

echo "(".$angka1."+".$angka5."+".$angka9.")+(".$angka7."+".$angka5."+".$angka3.") = ".$jumlah;