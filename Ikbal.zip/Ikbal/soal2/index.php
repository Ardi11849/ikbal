<?php
    function username ($username,$password){
        $hitungUsername = strlen($username);
        $hitungPassword = strlen ($password);

        if ($hitungUsername > 12){
            $husername = 'username: false<br>';
        }elseif(!preg_match('/^@/', $username)){
            $husername = 'username: false<br>';
        }else{
            $husername = 'username: true<br>';
        }


        if($hitungPassword > 6){
            $hpassword = 'password: false<br>';
        }elseif ($hitungPassword < 6) {
            $hpassword = 'password: false<br>';
        }elseif (is_string($password)){
            $hpassword = 'password: false<br>';
        }else{
            $hpassword = 'password: true<br>';
        }
        echo 'Username: '.$username.'<br>';
        echo 'Password: '.$password.'<br>';
        echo $husername;
        echo $hpassword;    
    }

    username ('ikbalmuze', 222004);
    

