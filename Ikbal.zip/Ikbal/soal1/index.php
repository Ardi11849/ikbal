<?php
function biodata($nama, $umur){
    $addres = 'Perumahan BCI 02/19, Desa tenjolaya Kec.Pasirjambu Kab.Bandung';
    $Hobbies = array('hiking' , 'fishing');
    $married=false;
    
    if($married == false) {
        $is_married = "Belum Menikah";
    }else{
        $is_married = "Sudah Menikah";
    }

    $school = array ('nama'=> 'ikbal', 'year_in'
    =>'2015', 'year_out'=>'2018','major'=>'');

    $skill = array ('skill_name'=>'programming', 'level'=> 'beginer');

    $interest=true;

    if($interest == true){
        $interest = "Yes";
    }else{
        $interest ="No";
    }
    $hasil = array($nama , $umur, $addres, $married, $is_married, $school,$skill,$interest);

    echo json_encode($hasil);
}

biodata('ikbal','21');

